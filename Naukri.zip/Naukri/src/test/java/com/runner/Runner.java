package com.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
features = "src\\main\\resources\\features\\naukri.feature",
plugin = {"pretty", "html:reports/cucumber-html-report","json:reports/cucumber-html-report/jsonreport","com.cucumber.listener.ExtentCucumberFormatter:reports/Extentreports/Extentreport.html"},
tags = {"@tc01_login,@tc02_AboutCompanies,@tc03_SalaryPredictor,@tc04_AdvancedSearchoption"},
glue = {"com.stepdefiniton"},
monochrome = true
)
public class Runner {

}
