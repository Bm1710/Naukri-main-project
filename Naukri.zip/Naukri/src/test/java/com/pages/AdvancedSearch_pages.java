package com.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;



public class AdvancedSearch_pages {
	static WebDriver driver;

	//To launch the browser
	public void launchChrome(String browser)
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","C:\\844924\\Naukri\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
//To launch internetExplorer browser
		else if(browser.equalsIgnoreCase("Explorer"))
		{
			System.setProperty("webdriver.ie.driver","C:\\844924\\Naukri\\Drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	//To open the url
	public void url()
	{
		driver.get("https://www.naukri.com/");
		String windowTitle= getCurrentWindowTitle();
		String mainWindow = getMainWindowHandle(driver);
		Assert.assertTrue(closeAllOtherWindows(mainWindow));
		Assert.assertTrue(windowTitle.contains("Jobs - Recruitment"));
	}
		
	public String getMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	public String getCurrentWindowTitle() {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}
	
	//To close all the other windows except the main window.
	public static boolean closeAllOtherWindows(String openWindowHandle) {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(openWindowHandle)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}
		}
		
		driver.switchTo().window(openWindowHandle);
		if (driver.getWindowHandles().size() == 1)
			return true;
		else
			return false;
	}
	//To Login in to naukri
	public void login_search() throws IOException
	{   
        driver.findElement(By.xpath("//*[@id=\"login_Layer\"]/div")).click();
		driver.findElement(By.id("eLoginNew")).sendKeys("suryatejayalla96@gmail.com");
		driver.findElement(By.id("pLogin")).sendKeys("bmseven@7");
		driver.findElement(By.xpath("//*[@id=\"lgnFrmNew\"]/div[9]/button")).click();
	}
	// To search the required job
	public void search_job() throws InterruptedException {
		
		
		//Mouse-over actions
		WebElement a1 = driver.findElement(By.xpath("/html/body/div[1]/div/div/ul[1]/li[3]/a"));
		WebElement a2 = driver.findElement(By.xpath("/html/body/div[1]/div/div/ul[1]/li[3]/div/ul/li[2]/a"));
		Actions act = new Actions(driver);
		act.moveToElement(a1);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		act.moveToElement(a2).click().build().perform();
		
		
		driver.findElement(By.xpath("//*[@id=\"qsbForm\"]/div[2]/a")).click();
		
		
	    driver.findElement(By.xpath("//*[@id=\"advKeyskills\"]/div[1]/div[2]/input")).sendKeys("cognizant");
	    driver.findElement(By.xpath("//*[@id=\"Sug_advLocation\"]")).sendKeys("chennai");
		driver.findElement(By.xpath("//*[@id=\"adv_workExp_year\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_expyr6\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"adv_workExp_month\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_expmn2\"]")).click();   
		driver.findElement(By.xpath("//*[@id=\"adv_exp_min\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_min8\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"ddAdvIndusrty\"]/div[1]/ul/li/div/input")).click();
	    driver.findElement(By.xpath("//*[@id=\"ul_ddAdvIndusrty\"]/div/div[1]/ul/li[22]/a")).click();

	    
	    driver.findElement(By.xpath("//*[@id=\"adv_jobCategory\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"24\"]")).click();
	    
	    driver.findElement(By.xpath("//*[@id=\"advFrm\"]/div[7]/div[2]/div/div[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id=\"advFrm\"]/div[8]/div[2]/div/div[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id=\"adv_submit\"]")).click();
	    
	    
	    
	    
	    
	
		Thread.sleep(5000);
		//To close the driver
		driver.close();
		
	}

}
