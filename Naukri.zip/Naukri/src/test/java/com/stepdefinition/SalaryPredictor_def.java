package com.stepdefinition;

import java.io.IOException;

import com.pages.SalaryPredictor_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SalaryPredictor_def {

	SalaryPredictor_page sp= new SalaryPredictor_page(); //Creating an object

@Given("^user launched the chrome browser for the search scenario$")
public void user_launched_the_chrome_browser_for_the_search_scenario() {
    // Write code here that turns the phrase above into concrete actions
   sp.launchChrome("chrome");
}

@When("^user opens naukri homepage for the search scenario\\.$")
public void user_opens_naukri_homepage_for_the_search_scenario()  {
    // Write code here that turns the phrase above into concrete actions
    sp.url();
}

@Then("^users logins to the page$")
public void users_logins_to_the_page() throws IOException  {
    // Write code here that turns the phrase above into concrete actions
sp.loginn();
}

@Then("^user mouseovers on tools and clicks salary predictor$")
public void user_mouseovers_on_tools_and_clicks_salary_predictor() {
    // Write code here that turns the phrase above into concrete actions
   sp.mouseover("/html/body/div[1]/div/div/ul[1]/li[4]/a", "/html/body/div[1]/div/div/ul[1]/li[4]/div/ul/li[5]/a");
}

@Then("^enters the required fields and clicks submit$")
public void enters_the_required_fields_and_clicks_submit()  {
    // Write code here that turns the phrase above into concrete actions
  sp.details();
}

}
