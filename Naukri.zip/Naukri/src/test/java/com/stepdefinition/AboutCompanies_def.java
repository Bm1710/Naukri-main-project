package com.stepdefinition;


import java.io.IOException;

import com.pages.AboutCompanies_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AboutCompanies_def {

	AboutCompanies_page a=new AboutCompanies_page(); //Creating an object

@Given("^user launched the chrome browser$")
public void user_launched_the_chrome_browser()  {
    // Write code here that turns the phrase above into concrete actions
   a.launchChrome("chrome");
}

@When("^user opens naukri homepage$")
public void user_opens_naukri_homepage()  {
    // Write code here that turns the phrase above into concrete actions
   a.url();
}

@Then("^user clicks on login$")
public void user_clicks_on_login()  {
    // Write code here that turns the phrase above into concrete actions
    a.clicking("//*[@id=\"login_Layer\"]/div");
}

@Then("^user enters email$")
public void user_enters_email()  {
    // Write code here that turns the phrase above into concrete actions
   a.entering("eLoginNew", "suryatejayalla96@gmail.com");
}

@Then("^user enters password$")
public void user_enters_password() {
    // Write code here that turns the phrase above into concrete actions
    a.entering("pLogin", "bmseven@7");
}

@Then("^user click on login$")
public void user_click_on_login()  {
    // Write code here that turns the phrase above into concrete actions
a.clicking("//*[@id=\"lgnFrmNew\"]/div[9]/button");
}

@Then("^user mouse over on Companies$")
public void user_mouse_over_on_Companies()  {
   // Write code here that turns the phrase above into concrete actions
    a.mouseover();
}



@Then("^user takes a screenshot$")
public void user_takes_a_screenshot() throws IOException  {
    // Write code here that turns the phrase above into concrete actions
a.screenshot("C:\\844924\\Naukri\\Screenshots\\companies.jpg");
}


}
